import React, {useState, useEffect} from 'react';
// eslint-disable-next-line


function App() {
  const [sena, setSena] = useState([])
  

   

  useEffect(() => {    

    let aux=[]    
    while(1){
      if(aux.length>=6){break}
      let random = getRandomInt()
      let test = aux.find(item => { item == random})
      if(!test){
        aux.push(getRandomInt())
      }
    }
    setSena([...aux])
  }, [])

  function getRandomInt() {
    return Math.floor(Math.random() * Math.floor(61-1)+1 );

  } 
 

  return (
    <div className="App"
    style={
      {display: "flex",
      justifyContent: "center",
      alignItems: "center",
      backgroundColor: "#ccc",
      width: "100vw",
      height: "100vh"}
    }
    >
      {sena.map((numero) => (
        <h1 key={numero.toString()}
          style={
            {marginRight: "8px",
            color: "rgb(43, 70, 226)"}
          }
        
        
        >{numero}</h1>))}
      
    </div>
  );
}

export default App;
